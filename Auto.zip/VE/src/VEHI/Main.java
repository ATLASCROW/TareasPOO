
package VEHI;

public class Main {
     
    private String marca;
    private String modelo;
    private int kilometraje;
   // private String color;
    private int año;
    //private String estado;
    
    
    //get(obtener) set (dar)
    
    //setes
     public void setMarca(String marca){
         this.marca=marca;
     }
     
     public String getMarca(){
         return marca;
     }
     
     public void setModelo(String modelo){
         this.modelo=modelo;
     }
     
     public String getModelo(){
         return modelo;
     }
     
     public void setKilometraje(int kilometraje){
         this.kilometraje=kilometraje;
     }
     
     public int getKilometraje(){
         return kilometraje;
     }
     
     //public void setColor(String color){
         //this.color=color;
     //}
     
    // public String getColor(){
         //return color;
     //}
     
     public void setAño(int año){
         this.año=año;
     }
     
     public int getAño(){
         return año;
     }
     
     //public void setEstado(String estado){
        // this.estado=estado;
     //}
     
    // public String getEstado(){
         //return estado;
     //}
     
}

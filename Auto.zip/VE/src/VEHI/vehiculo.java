
package VEHI;

public class vehiculo {
    
    public static void main(String[] args){
        
        
        System.out.println("===DATOS DEL VEHICULO====");
        
        Main objeto = new Main();
        
        
        
        objeto.setMarca("Toyota");
        System.out.println("La marca del vehiculo es: " +objeto.getMarca());
        
   
        objeto.setModelo("Tacoma");
        System.out.println("El modelo del vehiculo es: "+objeto.getModelo());
        
        
        objeto.setAño(2023);
        System.out.println("El Año del vehiculo  es: " +objeto.getAño());
        
        objeto.setKilometraje(245);
        System.out.println("El kilometraja del vehiculo es: " +objeto.getKilometraje() );
        
      
        //objeto.setColor("Plateado");
       // System.out.println("El color del vehiculo es: "+objeto.getColor() );
              
        
       // objeto.setEstado("Nuevo");
        //System.out.println("EL estado del motor del vehiculo es: "+objeto.getEstado());
        
        
    }
}

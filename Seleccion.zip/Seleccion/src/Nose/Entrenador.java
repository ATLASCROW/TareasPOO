
package Nose;

public class Entrenador  extends Seleccion{
    private String idFederacion;
    
    public Entrenador(int id, String nombre, String apellidos, int edad, String idFederacion){
        super(id,nombre,apellidos,edad);
        this.idFederacion=idFederacion;
    }

    public String getIdFederacion() {
        return idFederacion;
    }

    public void setIdFederacion(String idFederacion) {
        this.idFederacion = idFederacion;
    }
    
    //Metodos
    public void dirigirPartido(){
        System.out.println("=======ENTRENADOR======");
        System.out.println("El Entrenador "+getNombre()+" dirigio un partido");
    }
    
    public void dirigirEntrenamiento(){
        System.out.println("El entrenador "+getNombre()+" dirigio un entrenamiento");
    }
    
    public void mostrardatos (){
        System.out.println("=======DATOS DEL ENTRENADOR======");
        System.out.println("El id del entrenador es: "+getId());
        System.out.println("El nombre del entrenador es: "+getNombre());
        System.out.println("Los apellidos del entrenador son: "+getApellidos());
        System.out.println("El entrenador  " +getNombre()+ " tiene: "+getEdad()+" años de edad");
        System.out.println("El nombre de la ferederacion del entrenador es: "+getIdFederacion());
    }
}
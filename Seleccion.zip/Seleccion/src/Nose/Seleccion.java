
package Nose;

public class Seleccion{
    private Integer id;
    private String nombre;
    private String apellidos;
    private Integer edad;
    
    public Seleccion(int id, String nombre, String apellidos, int edad){
      this.id=id;
      this.nombre=nombre;
      this.apellidos=apellidos;
      this.edad=edad;
    }
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public Integer getEdad() {
        return edad;
    }

    public void setEdad(Integer edad) {
        this.edad = edad;
    }

   
    
    //Metodos pero no se como llamarlos desde la clase main :(
    
    public void Concentrarse(){
        System.out.println("La seleccion realizo un espacio de concentracion");
    }
    
    public void Viajar(){
        System.out.println("La seleccion realizo un viaje ");
    }
   
}

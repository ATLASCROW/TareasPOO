
package Nose;

public class Masajista extends Seleccion{
    private String titulacion;
    private Integer anioExperiencia;
    
    public Masajista(int id, String nombre,String apellidos, Integer edad,String titulacion, Integer anioExperiencia)
    { 
        super(id, nombre,apellidos, edad);
        this.titulacion=titulacion;
        this.anioExperiencia=anioExperiencia;
    }

    public String getTitulacion() {
        return titulacion;
    }

    public void setTitulacion(String titulacion) {
        this.titulacion = titulacion;
    }

    public Integer getAnioExperiencia() {
        return anioExperiencia;
    }

    public void setAnioExperiencia(Integer anioExperiencia) {
        this.anioExperiencia = anioExperiencia;
    }
    
    //Metodos
    
    public void darMasaje(){
        System.out.println("====MASAJISTA======");
        System.out.println("El masajista "+getNombre()+" realizo un masaje"); 
    }
    
    public void mostrardatos (){
        System.out.println("====DATOS DEL MASAJISTA======");
        System.out.println("El id del masajista es: "+getId());
        System.out.println("El nombre del masajista es: "+getNombre());
        System.out.println("Los apellidos del masajista son: "+getApellidos());
        System.out.println("El masajista: "+getNombre()+ " tiene: " +getEdad()+" años de edad");
        System.out.println("El señor :" +getNombre()+ " se titulo en: "+getTitulacion());
        System.out.println("El masajista: "+getNombre()+" tiene: "+getAnioExperiencia()+" años de experiencia");
    }
}

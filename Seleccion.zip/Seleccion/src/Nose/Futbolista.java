
package Nose;

public class Futbolista extends Seleccion{
    private Integer dorsal;
    private String demarcacion;
    
    public Futbolista(Integer id, String nombre,String apellidos, Integer edad,Integer dorsal, String demarcacion){
        super(id, nombre,apellidos, edad);
        this.dorsal=dorsal;
        this.demarcacion=demarcacion;
    }

    public Integer getDorsal() {
        return dorsal;
    }

    public void setDorsal(Integer dorsal) {
        this.dorsal = dorsal;
    }

    public String getDemarcacion() {
        return demarcacion;
    }

    public void setDemarcacion(String demarcacion) {
        this.demarcacion = demarcacion;
    }
    
    
    //Metodos 
    
    public void jugarPartido(){
        System.out.println("======FUTBOLISTA========");
        System.out.println("El jugador "+getNombre()+" jugo un partido");
    }
    
    public void entrenar(){
        System.out.println("El jugador "+getNombre()+" hizo su entrenamiento diario");
    }
    
    public void mostrardatos (){
        System.out.println("======DATOS DEL FUTBOLISTA========");
        System.out.println("El id del jugador es: "+getId());
        System.out.println("El nombre del jugador es: "+getNombre());
        System.out.println("Los apellidos del jugador son: "+getApellidos());
        System.out.println("El jugador  "+getNombre()+ " tiene: "+getEdad()+" años de edad");
        System.out.println("El jugador  " +getNombre()+" juega con el numero: "+getDorsal());
        System.out.println("El jugador  "+getNombre()+" juega en la posicion de: "+getDemarcacion());
    }
}

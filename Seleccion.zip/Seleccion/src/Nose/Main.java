
package Nose;

public class Main {
    
    public static void main (String[]args){
     
        
        Futbolista fut1 = new Futbolista (4585,"Carlos","Piedra Gonzaga",20,5,"Central");
        Entrenador ent1 = new Entrenador (4785,"Felipe", "Crespo Fernandez",40,"FEF");
        Masajista masaj1 = new Masajista (7845,"Roberto", "Cordova Islas", 32,"Masajista",8);
        
        System.out.println("===CONCENTRACION===");
        System.out.println("La seleccion realizo un espacio de concentracion");
        System.out.println("===Viajar=====");
        System.out.println("La seleccion viajo para su partido");
                        
        
        fut1.jugarPartido();
        fut1.entrenar();
        fut1.mostrardatos();
        ent1.dirigirPartido();
        ent1.dirigirEntrenamiento();
        ent1.mostrardatos();
        masaj1.darMasaje();
        masaj1.mostrardatos();
    }
}
